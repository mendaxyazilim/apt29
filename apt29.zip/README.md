# APT29 v1
## Author: github.com/mendaxyazilim
### For more: https://mendaxyazilim.com

## Legal disclaimer:
Usage of APT29 for attacking targets without prior mutual consent is illegal. It's the end user's responsibility. Developers assume no liability and are not responsible for any misuse or damage caused by this program.

##### Usage:
```
git clone https://github.com/mendaxyazilim/apt29.git
cd APT29
chmod +x apt29.sh
./apt29.sh
```
